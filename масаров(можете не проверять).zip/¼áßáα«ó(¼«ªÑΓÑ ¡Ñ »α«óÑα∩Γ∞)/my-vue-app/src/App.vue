<script setup>

</script>

<template>
<h1>приложение SPA</h1>

</template>

<style scoped>

</style>
